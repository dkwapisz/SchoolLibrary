create definer = s401343@localhost trigger check_max_rentals
    before insert
    on actual_rentals
    for each row
BEGIN
        IF (SELECT count(uid) FROM actual_rentals WHERE uid = NEW.uid) >= 5 THEN
            SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Rental limit (5)';
        END IF;
END;

